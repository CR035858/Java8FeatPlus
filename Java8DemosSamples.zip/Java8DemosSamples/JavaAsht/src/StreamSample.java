import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stream <Integer> myStream = Stream.of(10,20,30,40,50);
		Integer nums[] = {100,200,300,400,500};
		
		List <Integer> myList = myStream.collect(Collectors.toList());
		System.out.println(myList);
		
		Stream <Integer> myStream1 = myList.stream();
		
		List <Integer> myList1 = myStream1.collect(Collectors.toList());
		
		System.out.println(myList1);
		
					Stream <Integer> myStream2 = myList1.parallelStream();
					List <Integer> myList2 = myStream2.collect(Collectors.toList());
					System.out.println(myList2);
					Stream <Integer> myStr2 = myStream2.sorted();
							
					myList2.stream()                           // Created a stream from the list
	                .filter(num -> num > 10)        //filter operation to get only numbers greater than 10
	                .forEach(System.out::println);  //
		
					List <String> myList3 =new ArrayList<String>();
					myList3.add("Dave");
					myList3.add("Raj");
					myList3.add("Kiran");
					myList3.add("Suman");
					myList3.add("Amar");
					myList3.add("Emanuel");
					
					
					myList3.stream()
	                .map(name -> name.toUpperCase()) //map() takes an input of Function<T, R> type.
	                .forEach(System.out::println);
					
					Stream<Integer> stream11 = Stream.of(1,2,3,4,5,6,7,8,9);
			        stream11.forEach(p -> System.out.println(p));
		

	}

}
