interface MyFunctional
{
	public void display();
}
interface MyFunctional1
{
	public void calculate(int a ,int b);
}
interface InterestCal
{
	public double calculateSI(int p,int t,int r);
}
interface Customer
{
	public void calculateSalesAmt(int i, int j);
}
interface Sales
{
	public void calculateSales(int a, int b,Customer c);
}
public class LambdaSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyFunctional mf = () ->{System.out.println("The Functional Interface1 ");};
		mf.display();
		MyFunctional1 mf1 = (int a,int b)->{ 
			int result = a + b;
			System.out.println("The sum is "+result);
			};
			
			mf1.calculate(100, 200);
		InterestCal  ic = (int a,int b,int c) ->
		{
			return ( a * b * c)/100;
		};
		double sInt = ic.calculateSI(10000, 2, 8);
		System.out.println("the Simple INterest is "+sInt);
		
		Customer c= (int j,int k) ->
		{
			int totalCost = j * k;
			System.out.println("the Cost is "+totalCost);
		};
		
		c.calculateSalesAmt(100, 50);
		Sales s = (int a,int b,Customer c1)->
		{
			c1.calculateSalesAmt(a, b);
		};
			
	}

}
