interface MyFInterface
{
	void display();
}
interface Banking
{
	void calculate(int a,int b);
}
interface AccountHolder
{
	void createAccount(int i,int j,Banking b);
}/**/
public class FunctionalInterfaceSample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/*	MyFInterface mf1 = () -> { System.out.println("We are understanding Functional Interfaces");};
		
		MyFInterface mf2 = () -> {System.out.println("Functional Interfaces are Interfaces with only 1 abstract Method");};
		
		MyFInterface mf3 = () -> { System.out.println("Functional Interfaces are implemented thru Lambda Expressions..");};
		
		MyFInterface mf4 = () -> { 
			System.out.println("Lambda Expressions are powerful Programming Constructs...");
			System.out.println("Lambda EXpressions enable one to treat functions as Objects");
			System.out.println("Lambda EXpressions enable one to pass functions as arguments to another function");
			System.out.println("Lambda Expression load functions dynamically");
		};
		
		mf1.display();
		System.out.println("-----------");
		mf2.display();
		System.out.println("-----------");
		mf3.display();
		System.out.println("-----------");
		mf4.display();
		System.out.println("-----------"); */
		
		Banking sbi = (int x,int y) -> { 
			int result;
			result = x + y;
			System.out.println("The Sum is "+result);
			};
			
		Banking icici = (int p,int q) -> {
			int result;
			result = p * q;
			System.out.println("The Product is "+result);
			
			};
			
			sbi.calculate(100, 200);
			System.out.println("---------------------");
			icici.calculate(100, 200);
			
		AccountHolder  ramana = (int i,int j,Banking bank) -> { 
			
			int actualInterest = (i * j)+(1000);
			System.out.println("Actual Interest accumulated is "+actualInterest);
			bank.calculate(i+10, j+10);// 110 210
		};
		
		ramana.createAccount(10, 20, icici);
		System.out.println("------------");
		ramana.createAccount(100,200,sbi);
			
	}

}
