import java.util.ArrayList;
import java.util.Collections;

public class LambdaExprSample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Supplier> suppliers = new ArrayList<Supplier>();
		
		suppliers.add(new Supplier("S005","Zeenat","Faridabad",30000));
		suppliers.add(new Supplier("S006","Amarendar","Dharwad",90000));
		suppliers.add(new Supplier("S004","David","Bangalore",20000));
		suppliers.add(new Supplier("S003","Ganesh","Bhopal",40000));
		suppliers.add(new Supplier("S002","Faheem","Ahmedabad",70000));
		suppliers.add(new Supplier("S001","Emanuel","Chennai",80000));
		
		//Collections.sort(suppliers, new IdSorter());
		Collections.sort(suppliers, (s1,s2) -> { return s1.supplierId.compareTo(s2.supplierId); });
		System.out.println("Suppliers Sorted w.r.t SUpplier ID .....");
		for(Supplier s : suppliers)
		{
			System.out.println(s);
		}
		Collections.sort(suppliers, (s1,s2) -> { return s1.supplierCity.compareTo(s2.supplierCity); });
		System.out.println("Suppliers Sorted w.r.t SUpplier City .....");
		for(Supplier s : suppliers)
		{
			System.out.println(s);
		}

	}

}
