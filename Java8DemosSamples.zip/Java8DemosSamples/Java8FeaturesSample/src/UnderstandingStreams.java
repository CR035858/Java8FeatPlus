import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class UnderstandingStreams {
	//Sum of squares of all odd inetegers from 1 to 5
	public void functional()
	{
		List <Integer> numbers = Arrays.asList(1,2,3,4,5);
		
		Stream <Integer> numberStream = numbers.stream();
		
		Stream <Integer> oddNumberStream = numberStream.filter(x -> x % 2 ==1);
		
		Stream <Integer> squaredNumberStream = oddNumberStream.map(x -> x * x);
		
		int sum = squaredNumberStream.reduce(0, (x,y) -> x+y);
		System.out.println("Functional Sum of Odd Integers 1-5 "+sum);
		
		System.out.println("----------------");
	int sum1 = numbers.stream()
				.filter(x -> x % 2 == 1)
				.map(x -> x * x) /**/
				.reduce(0, (x,y) -> x+y);
			System.out.println("Sum is "+sum1);	
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		UnderstandingStreams uStreams = new UnderstandingStreams();
		uStreams.functional();

	}

}
