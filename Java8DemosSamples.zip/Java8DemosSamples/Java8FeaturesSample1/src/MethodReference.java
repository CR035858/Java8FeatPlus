interface Sayable{  
    void say();  
}  
public class MethodReference {

	 	public static void saySomething(){  
	        System.out.println("Hello, this is static method.");  
	    }  

		public static void saySomethingNew()
		{
			System.out.println("Hello,This is Another Static Method ");
		}
		public static void sayAnotherThing()
		{
			System.out.println("Hello He Says another thing...");
		}
		public static void threadMethod()
		{
			System.out.println("This Method is a Thread Method Now....");
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 // Referring static method  
        Sayable sayable = MethodReference::saySomething;  
        // Calling interface method  
        sayable.say();  
        
        sayable = MethodReference::sayAnotherThing;
        sayable.say();
        
        Sayable sayable1 = MethodReference::saySomethingNew;
        sayable1.say();
        
        Thread t1 = new Thread(MethodReference::threadMethod);
        t1.start();
	}

}
