interface MyInterface1
{
	public void display();
}
interface MyInterface2
{
	public void calculate(int a,int b);
}
interface Customer
{
	public void calculateInvoiceAmt(int qty,int price);
}
interface NewCustomer
{
	public double calculateInvoiceAmt(int qty,int price);
}
interface SalesData
{
	public void processOrder(int qty,int price,NewCustomer c);
}
public class FunctionalInterfaceClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyInterface1 inter1 = () -> {System.out.println("Welcome to Functional Interfaces..");};
		
		inter1.display();
		System.out.println("---------------------");
		MyInterface2 inter2 = (int x,int y) -> { 
			
			int result =  x + y;
			System.out.println("The Sum is "+result);
			
		};
		System.out.println("---------------------");
		inter2.calculate(100, 200);
		
		System.out.println("---------------------");
		MyInterface2 inter3 = (int i,int j) ->
		{
			int result  =  i * j;
			System.out.println("The Product is "+result);
			if(result >= 20000)
			{
				System.out.println("Good Result");
			}
			else
			{
				System.out.println("Moderate Result");
			}
		};
		inter3.calculate(200,40);
		System.out.println("------------------------------------------");
		Customer c1 = (int q,int p) -> {
			int invoiceAmt = q * p;
			System.out.println("Invoice Amount is "+invoiceAmt);
			if (invoiceAmt >= 10000)
			{
				System.out.println("Eligible for Discount");
			}
			else
			{
				System.out.println("Sorry Not Eligible for Discount");
			}
		};
		System.out.println("-------------Customer details-----------------------------");
		c1.calculateInvoiceAmt(100, 50);
		c1.calculateInvoiceAmt(100, 120);
		c1.calculateInvoiceAmt(100, 200);
		System.out.println("--------------------------SALES DATA--------------------------------");
		NewCustomer cust1 = (int qty,int price)->
		{
			int totValue = qty * price;
			double finalSaleValue = totValue - (0.1 * totValue);
			return finalSaleValue;
		};
		NewCustomer cust2 = (int qty,int price)->
		{
			int totValue = qty * price;
			double finalSaleValue = totValue - (0.2 * totValue);
			return finalSaleValue;
		};
		System.out.println("-------------------------Understanding LambdaExpression as function defns -------");
		SalesData sd1 = (int q,int p,NewCustomer nc1)->{
			int actualInvoiceValue = q * p;
			System.out.println("The Actual Invoice Value is "+actualInvoiceValue);
			double finalSaleValue = nc1.calculateInvoiceAmt(q, p);
			System.out.println("The Final Sale Value for Cust1 "+finalSaleValue);
			
		};
		
		SalesData sd2 = (int q1,int p1,NewCustomer nc2)->{
			int actualInvoiceValue = q1 * p1;
			System.out.println("The Actual Invoice Value is "+actualInvoiceValue);
			double finalSaleValue = nc2.calculateInvoiceAmt(q1, p1);
			System.out.println("The Final Sale Value for Cust2 "+finalSaleValue);
		};
		
			sd1.processOrder(100, 250, cust1);
			
			sd2.processOrder(100, 250, cust2);
	}

		
}
