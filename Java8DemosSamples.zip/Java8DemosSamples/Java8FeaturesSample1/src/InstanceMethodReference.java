interface Sayable2{  
    void say();  
}  
public class InstanceMethodReference {

	public void printnMsg(){  
        System.out.println("Hello, this is instance method accessed Thru Thread...");  
    }  
	   public void saySomething(){  
	        System.out.println("Hello, this is non-static method.");  
	    }  
		public static void main(String[] args) {
			// TODO Auto-generated method stub
	
			 InstanceMethodReference methodReference = new InstanceMethodReference(); // Creating object  
		        // Referring non-static method using reference  
		            Sayable2 sayable = methodReference::saySomething;  
		        // Calling interface method  
		            sayable.say();  
		            // Referring non-static method using anonymous object  
		            Sayable2 sayable2 = new InstanceMethodReference()::saySomething; // You can use anonymous object also  
		            // Calling interface method  
		            sayable2.say();  
		            
		            Thread t2=new Thread(new InstanceMethodReference()::printnMsg);  
		            t2.start();
		}

}
