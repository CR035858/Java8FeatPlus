import java.util.ArrayList;
import java.util.Collections;

public class LambdaExprEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList <Supplier> suppliers = new ArrayList<Supplier>();
		
		suppliers.add(new Supplier("S005","Zeenat","Faridabad",30000));
		suppliers.add(new Supplier("S007","Amarendar","Chennai",90000));
		suppliers.add(new Supplier("S004","Chandu","Bangalore",40000));
		suppliers.add(new Supplier("S003","Yasmeen","Dharwad",20000));
		suppliers.add(new Supplier("S001","Emanuel","Bhopal",60000));
		suppliers.add(new Supplier("S002","Ganesh","Ahmedabad",50000));
		suppliers.add(new Supplier("S006","David","Chandigarh",60000));
		
		
		Collections.sort(suppliers, (s1,s2) -> {return s1.supplierId.compareTo(s2.supplierId);});
		System.out.println("Suppliers sorted by Supplier Id..................");
		for(Supplier s:suppliers)
		{
			System.out.println(s);
		}
		Collections.sort(suppliers, (s1,s2) -> {return s1.supplierCity.compareTo(s2.supplierCity);});
		System.out.println("Suppliers sorted by Supplier City..................");
		for(Supplier s:suppliers)
		{
			System.out.println(s);
		}
		Collections.sort(suppliers, (s1,s2) -> {return s1.supplierName.compareTo(s2.supplierName);});
		System.out.println("Suppliers sorted by Supplier Name..................");
		for(Supplier s:suppliers)
		{
			System.out.println(s);
		}
		
	}

}
